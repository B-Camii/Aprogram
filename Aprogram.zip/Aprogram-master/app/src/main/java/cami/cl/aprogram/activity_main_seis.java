package cami.cl.aprogram;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.sql.Connection;

public class activity_main_seis extends AppCompatActivity {
    TextView tvPreguntaDos;
    RadioGroup RGAlternativas;
    RadioButton RBAlt1;
    RadioButton RBAlt2;
    RadioButton RBAlt3;
    Button btnValidarSeis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_seis);

        tvPreguntaDos = (TextView) findViewById(R.id.tvPreguntaDos);
        RGAlternativas = (RadioGroup) findViewById(R.id.RGalternativas);
        RBAlt1 = (RadioButton) findViewById(R.id.RBAlt1);
        RBAlt2 = (RadioButton) findViewById(R.id.RBAlt2);
        RBAlt3 = (RadioButton) findViewById(R.id.RBAlt3);
        btnValidarSeis = (Button) findViewById(R.id.btnValidarSeis);

    }

    //crear conexion con base de datos
}
